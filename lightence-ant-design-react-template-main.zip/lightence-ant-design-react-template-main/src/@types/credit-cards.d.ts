declare module 'elt-react-credit-cards';
