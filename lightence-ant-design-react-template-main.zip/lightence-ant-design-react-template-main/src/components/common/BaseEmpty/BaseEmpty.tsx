export { Empty as BaseEmpty } from 'antd';
export type { EmptyProps as BaseEmptyProps } from 'antd';
