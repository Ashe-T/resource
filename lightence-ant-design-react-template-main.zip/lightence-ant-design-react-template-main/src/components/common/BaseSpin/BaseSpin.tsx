export { Spin as BaseSpin } from 'antd';
export type { SpinProps as BaseSpinProps } from 'antd';
