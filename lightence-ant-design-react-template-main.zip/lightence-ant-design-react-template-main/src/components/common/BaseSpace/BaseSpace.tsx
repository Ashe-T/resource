export { Space as BaseSpace } from 'antd';
export type { SpaceProps as BaseSpaceProps } from 'antd';
