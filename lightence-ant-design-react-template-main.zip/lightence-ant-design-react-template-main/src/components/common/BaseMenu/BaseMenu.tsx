export { Menu as BaseMenu } from 'antd';
export type { MenuProps as BaseMenuProps } from 'antd';
