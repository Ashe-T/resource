export { AutoComplete as BaseAutoComplete } from 'antd';
export type { AutoCompleteProps as BaseAutoCompleteProps } from 'antd';
