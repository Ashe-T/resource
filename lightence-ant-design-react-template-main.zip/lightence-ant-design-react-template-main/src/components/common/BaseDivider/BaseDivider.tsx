export { Divider as BaseDivider } from 'antd';
export type { DividerProps as BaseDividerProps } from 'antd';
