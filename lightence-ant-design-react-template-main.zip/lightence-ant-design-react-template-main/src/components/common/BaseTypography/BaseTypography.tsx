export { Typography as BaseTypography } from 'antd';
export type { TypographyProps as BaseTypographyProps } from 'antd';
