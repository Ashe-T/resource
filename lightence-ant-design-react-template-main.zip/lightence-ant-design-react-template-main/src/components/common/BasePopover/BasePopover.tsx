export { Popover as BasePopover } from 'antd';
export type { PopoverProps as BasePopoverProps } from 'antd';
