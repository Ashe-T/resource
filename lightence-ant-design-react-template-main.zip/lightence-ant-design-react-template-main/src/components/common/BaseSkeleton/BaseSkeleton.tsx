export { Skeleton as BaseSkeleton } from 'antd';
export type { SkeletonProps as BaseSkeletonProps } from 'antd';
