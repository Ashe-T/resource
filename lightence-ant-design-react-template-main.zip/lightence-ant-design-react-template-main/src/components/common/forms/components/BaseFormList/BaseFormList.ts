import { Form } from 'antd';
import styled from 'styled-components';

export const BaseFormList = styled(Form.List)``;
