import { BaseButton } from '@app/components/common/BaseButton/BaseButton';
import styled from 'styled-components';

export const Btn = styled(BaseButton)`
  width: 100%;
`;
