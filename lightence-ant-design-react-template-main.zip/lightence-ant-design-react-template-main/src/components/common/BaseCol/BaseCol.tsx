export { Col as BaseCol } from 'antd';
export type { ColProps as BaseColProps } from 'antd';
