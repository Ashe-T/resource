export { Tag as BaseTag } from 'antd';
export type { TagProps as BaseTagProps } from 'antd';
