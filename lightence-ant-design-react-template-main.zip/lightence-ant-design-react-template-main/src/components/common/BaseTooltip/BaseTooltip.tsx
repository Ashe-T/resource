export { Tooltip as BaseTooltip } from 'antd';
export type { TooltipProps as BaseTooltipProps } from 'antd';
