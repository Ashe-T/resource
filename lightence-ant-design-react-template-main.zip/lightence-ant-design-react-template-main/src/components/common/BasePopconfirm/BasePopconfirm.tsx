export { Popconfirm as BasePopconfirm } from 'antd';
export type { PopconfirmProps as BasePopconfirmProps } from 'antd';
