export { Upload as BaseUpload } from 'antd';
export type { UploadProps as BaseUploadProps } from 'antd';
