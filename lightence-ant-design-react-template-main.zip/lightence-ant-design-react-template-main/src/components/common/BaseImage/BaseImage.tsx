export { Image as BaseImage } from 'antd';
export type { ImageProps as BaseImageProps } from 'antd';
