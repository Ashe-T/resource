export { Breadcrumb as BaseBreadcrumb } from 'antd';
export type { BreadcrumbProps as BaseBreadcrumbProps } from 'antd';
