import { ReactNode } from 'react';

type ScreeningItems = ReactNode[];

export interface ScreeningsProps {
  screeningsItems: ScreeningItems;
}
