import styled from 'styled-components';

export const FeedWrapper = styled.div`
  overflow-y: auto;

  max-height: 500px;
`;
