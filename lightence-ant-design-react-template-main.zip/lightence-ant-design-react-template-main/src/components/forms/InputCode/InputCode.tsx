import React from 'react';

export const InputCode: React.FC = () => {
  return <div></div>;
};
