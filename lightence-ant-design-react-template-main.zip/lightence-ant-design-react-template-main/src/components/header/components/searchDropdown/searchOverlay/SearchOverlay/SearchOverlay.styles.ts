import styled from 'styled-components';

export const Menu = styled.div`
  max-height: 50vh;
  overflow-y: auto;
`;
