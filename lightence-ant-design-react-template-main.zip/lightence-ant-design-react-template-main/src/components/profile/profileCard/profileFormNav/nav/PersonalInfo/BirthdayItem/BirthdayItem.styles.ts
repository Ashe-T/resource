import { BaseDatePicker } from '@app/components/common/pickers/BaseDatePicker';
import styled from 'styled-components';

export const BirthdayPicker = styled(BaseDatePicker)`
  width: 100%;
`;
