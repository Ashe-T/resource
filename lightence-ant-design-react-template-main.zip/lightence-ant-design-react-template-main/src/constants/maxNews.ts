export const MAX_NEWS = 6;
