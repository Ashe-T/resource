export enum Priority {
  INFO,
  LOW,
  MEDIUM,
  HIGH,
}
